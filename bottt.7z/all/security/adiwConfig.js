module.exports = {
  'approval': {
    'num': '6289508082845',
    'text': "oke",
    'set': "👀 Harus mendapatkan persetujuan oleh creator script, Jika ingin memakai script ini",
    'greet': "*Disetujui Oleh Creator, Silahkan Restart Panel Atau Run Ulang script* ☠️ "
  },
  'creatorScript': '6289508082845',
  'filePath': "./all/approval",
  'checkFilePath': "../setting/osaragi.js",
  'codeToDetect': 'main();'
};